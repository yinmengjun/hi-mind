# coding: utf-8
import os
import pandas as pd


# 海外分行
# OVS_AREA = ['MCO', 'TPE', 'TOK', 'SEO', 'KOR', 'HCM', 'SGD', 'DXB', 'SYD', 'PRG', 'FRK', 'LXS', 'LXB', 'ENG', 'LON',
#             'TOR', 'NYK', 'JRN']


# SDM基础信息类
class BaseInfo:
    def __init__(self):
        # 模式
        self.subject = ""
        # 地区
        self.area = ""
        # 物理表
        self.tableabbr = ""
        # 物理表注释
        self.tablecomment = ""
        # 开发人员
        self.developer = ""
        # 开发日期
        self.developdt = ""
        # 主键
        self.pdmpk = ""
        # ETL作业名
        self.etljobname = ""
        # ETL跑批频率
        self.etlfreq = ""
        # ETL策略
        self.etlpolicy = ""
        # 数据作业范围条件
        self.datacondition = ""
        # F2策略更新列
        self.f2upsertcols = ""
        # F2策略更新主键
        self.f2upsertkey = ""
        # F5策略主键
        self.f5key = ""
        # F5策略ST_DT
        self.f5stdt = ""
        # F5策略END_DT
        self.f5enddt = ""
        # I策略条件
        self.appendcondition = ""

    def setsubject(self, i):
        self.subject = i

    def setarea(self, i):
        self.area = i

    def settableabbr(self, i):
        self.tableabbr = i

    def settablecomment(self, i):
        self.tablecomment = i

    def setdeveloper(self, i):
        self.developer = i

    def setdevelopdt(self, i):
        self.developdt = i

    def setpdmpk(self, i):
        self.pdmpk = i

    def setetljobname(self, i):
        self.etljobname = i

    def setetlfreq(self, i):
        self.etlfreq = i

    def setetlpolicy(self, i):
        self.etlpolicy = i

    def setdatacondition(self, i):
        self.datacondition = i

    def setf2upsertcols(self, i):
        self.f2upsertcols = i

    def setf2upsertkey(self, i):
        self.f2upsertkey = i

    def setf5key(self, i):
        self.f5key = i

    def setf5stdt(self, i):
        self.f5stdt = i

    def setf5enddt(self, i):
        self.f5enddt = i

    def setappendcondition(self, i):
        self.appendcondition = i

    def getsubject(self):
        return self.subject

    def getarea(self):
        return self.area

    def gettableabbr(self):
        return self.tableabbr

    def gettablecomment(self):
        return self.tablecomment

    def getdeveloper(self):
        return self.developer

    def getdevelopdt(self):
        return self.developdt

    def getpdmpk(self):
        return self.pdmpk

    def getetljobname(self):
        return self.etljobname

    def getetlfreq(self):
        return self.etlfreq

    def getetlpolicy(self):
        return self.etlpolicy

    def getdatacondition(self):
        return self.datacondition

    def getf2upsertcols(self):
        return self.f2upsertcols

    def getf2upsertkey(self):
        return self.f2upsertkey

    def getf5key(self):
        return self.f5key

    def getf5stdt(self):
        return self.f5stdt

    def getf5enddt(self):
        return self.f5enddt

    def getappendcondition(self):
        return self.appendcondition


# SDM逻辑组类
class Group:
    def __init__(self):
        self.groupno = ""
        self.groupnote = ""
        self.ignoreflag = ""
        self.frontsql = ""
        self.behindsql = ""
        self.tarcol = []
        self.tarcolnm = []
        self.tartype = []
        self.sorenv = []
        self.sortab = []
        self.sorcol = []
        self.sorcolnm = []
        self.sormap = []
        self.joinenv = []
        self.jointab = []
        self.jointabalias = []
        self.jointype = []
        self.joincondition = []
        self.condition = []

    def setgroupno(self, i):
        self.groupno = i

    def setgroupnote(self, i):
        self.groupnote = i

    def setignoreflag(self, i):
        self.ignoreflag = i

    def setfrontsql(self, i):
        self.frontsql = i

    def setbehindsql(self, i):
        self.behindsql = i

    def settarcol(self, i):
        self.tarcol.append(i)

    def settarcolnm(self, i):
        self.tarcolnm.append(i)

    def settartype(self, i):
        self.tartype.append(i)

    def setsorenv(self, i):
        self.sorenv.append(i)

    def setsorenv2(self, value):
        self.sorenv = value

    def setsortab(self, i):
        self.sortab.append(i)

    def setsorcol(self, i):
        self.sorcol.append(i)

    def setsorcolnm(self, i):
        self.sorcolnm.append(i)

    def setsormap(self, i):
        self.sormap.append(i)

    def setjoinenv(self, i):
        self.joinenv.append(i)

    def setjoinenv2(self, value):
        self.joinenv = value

    def setjointab(self, i):
        self.jointab.append(i)

    def setjointabalias(self, i):
        self.jointabalias.append(i)

    def setjointype(self, i):
        self.jointype.append(i)

    def setjoincondition(self, i):
        self.joincondition.append(i)

    def setcondition(self, i):
        self.condition.append(i)

    def getgroupno(self):
        return self.groupno

    def getgroupnote(self):
        return self.groupnote

    def getignoreflag(self):
        return self.ignoreflag

    def getfrontsql(self):
        return self.frontsql

    def getbehindsql(self):
        return self.behindsql

    def gettarcol(self):
        return self.tarcol

    def gettarcolnm(self):
        return self.tarcolnm

    def gettartype(self):
        return self.tartype

    def getsorenv(self):
        return self.sorenv

    def getsortab(self):
        return self.sortab

    def getsorcol(self):
        return self.sorcol

    def getsorcolnm(self):
        return self.sorcolnm

    def getsormap(self):
        return self.sormap

    def getjoinenv(self):
        return self.joinenv

    def getjointab(self):
        return self.jointab

    def getjointabalias(self):
        return self.jointabalias

    def getjointype(self):
        return self.jointype

    def getjoincondition(self):
        return self.joincondition

    def getcondition(self):
        return self.condition


# excel解析类
def sdmanalysis(sdmsheet):
    # 定义常量
    tblblockflg = 0
    jobblockflg = 0
    mapblockflg = 0
    # othernotflg = 0

    # 声明基础信息类
    basicinfo = BaseInfo()

    # 声明逻辑组类
    obj = Group()

    # 声明group数组
    mapblock = []

    for i, row in sdmsheet.iterrows():
        for j, content in enumerate(row):
            if tblblockflg == 0 and content == "Physical table basic information":
                tblblockflg = 1
                jobblockflg = 0
                mapblockflg = 0
                # othernotflg = 0
            elif jobblockflg == 0 and content == "ETL Jobs information":
                tblblockflg = 0
                jobblockflg = 1
                mapblockflg = 0
                # othernotflg = 0
            elif mapblockflg == 0 and content == "Mapping information":
                tblblockflg = 0
                jobblockflg = 0
                mapblockflg = 1
                # othernotflg = 0
            # elif content == "Others":
            #     tblblockflg = 0
            #     jobblockflg = 0
            #     mapblockflg = 0
            #     othernotflg = 0
            else:
                if tblblockflg == 1:
                    if content == "Subject":
                        basicinfo.setsubject(row[j + 1])
                    elif content == "Table abbr.":
                        basicinfo.settableabbr(row[j + 1])
                    elif content == "Table comment":
                        basicinfo.settablecomment(row[j + 1])
                    elif content == "Developer":
                        basicinfo.setdeveloper(row[j + 1])
                    elif content == "Date Developed":
                        basicinfo.setdevelopdt(row[j + 1])
                    elif content == "Area":
                        basicinfo.setarea(row[j + 1])
                    elif content == "PK Column in\nPDM":
                        basicinfo.setpdmpk(row[j + 1])
                elif jobblockflg == 1:
                    if content == "ETL Job Name":
                        basicinfo.setetljobname(row[j + 1])
                    elif content == "ETL\nFrequency":
                        basicinfo.setetlfreq(row[j + 1])
                    elif content == "ETL policy":
                        basicinfo.setetlpolicy(row[j + 1])
                    elif content == "What data will be processed":
                        basicinfo.setdatacondition(row[j + 2])
                    elif content == "What columns will be updated":
                        basicinfo.setf2upsertcols(row[j + 2])
                        basicinfo.setf2upsertkey(sdmsheet.iloc[i + 1, j + 2])
                    elif content == "PK Column":
                        basicinfo.setf5key(row[j + 2])
                    elif content == "Column name of start date":
                        basicinfo.setf5stdt(row[j + 2])
                    elif content == "Column name of end date":
                        basicinfo.setf5enddt(row[j + 2])
                    elif content == "Append condition":
                        basicinfo.setappendcondition(row[j + 3])
                elif mapblockflg == 1:
                    if content == "Group No.":
                        obj.setgroupno(row[j + 1])
                    elif content == "Group note":
                        obj.setgroupnote(row[j + 1])
                    elif content == "Ignore following mapping":
                        obj.setignoreflag(row[j + 2])
                    elif content == "Front SQL Clause":
                        obj.setfrontsql(row[j + 2])
                    elif content == "Column name":
                        st_row = i + 1
                        st_col = j
                        while True:
                            if sdmsheet.iloc[st_row, st_col] == "Table join":
                                break
                            else:
                                obj.settarcol(sdmsheet.iloc[st_row, st_col])
                                obj.settarcolnm(sdmsheet.iloc[st_row, st_col + 1])
                                obj.settartype(sdmsheet.iloc[st_row, st_col + 2])
                                obj.setsorenv(sdmsheet.iloc[st_row, st_col + 3])
                                obj.setsortab(sdmsheet.iloc[st_row, st_col + 4])
                                obj.setsorcol(sdmsheet.iloc[st_row, st_col + 5])
                                obj.setsorcolnm(sdmsheet.iloc[st_row, st_col + 6])
                                obj.setsormap(sdmsheet.iloc[st_row, st_col + 8])
                                st_row += 1
                    elif content == "Table join":
                        st_row = i + 2
                        st_col = j
                        while True:
                            if sdmsheet.iloc[st_row, st_col] == "Other Statement":
                                break
                            else:
                                obj.setjoinenv(sdmsheet.iloc[st_row, st_col])
                                obj.setjointab(sdmsheet.iloc[st_row, st_col + 1])
                                obj.setjointabalias(sdmsheet.iloc[st_row, st_col + 2])
                                obj.setjointype(sdmsheet.iloc[st_row, st_col + 3])
                                obj.setjoincondition(sdmsheet.iloc[st_row, st_col + 4])
                                st_row += 1
                    elif content == "Other Statement":
                        st_row = i + 1
                        st_col = j
                        while True:
                            if sdmsheet.iloc[st_row, st_col] == "Embedded SQL":
                                break
                            else:
                                obj.setcondition(sdmsheet.iloc[st_row, st_col])
                                st_row += 1
                    elif content == "Behind SQL Clause":
                        obj.setbehindsql(row[j + 2])
                        mapblock.append(obj)
                        obj = Group()
    return basicinfo, mapblock


# 生成函数
def scriptproduce(basicinfo, mapblock, filepath):
    scriptpath = filepath + basicinfo.getsubject().strip().upper() + "_" + basicinfo.getarea().strip().upper() + "_" + basicinfo.getetljobname().strip().upper() + "\\SQL\\"
    ddlpath = filepath + basicinfo.getsubject().strip().upper() + "_" + basicinfo.getarea().strip().upper() + "_" + basicinfo.getetljobname().strip().upper() + "\\DDL\\"

    if not os.path.exists(scriptpath):
        os.makedirs(scriptpath)

    if not os.path.exists(ddlpath):
        os.makedirs(ddlpath)

    # 新建脚本
    script = basicinfo.getsubject().strip().lower() + "_" + basicinfo.getarea().strip().lower() + "_" + basicinfo.getetljobname().strip().lower() + "0200.sql"
    ddlsql = basicinfo.getetljobname().strip().upper() + ".sql"

    file = open(scriptpath + script, 'w', encoding='utf-8')
    ddlfile = open(ddlpath + ddlsql, 'w', encoding='utf-8')

    # 生成DDL脚本
    # ddlfile.write(
    #     "DROP VIEW IF EXISTS " + basicinfo.getarea().strip().upper() + "_PDMVIEW." + basicinfo.gettableabbr().strip().upper() + ";")
    # ddlfile.write("\n")
    # ddlfile.write(
    #     "DROP TABLE IF EXISTS " + basicinfo.getarea().strip().upper() + "_PMDATA." + basicinfo.gettableabbr().strip().upper() + ";")
    # ddlfile.write("\n")
    ddlfile.write(
        "CREATE TABLE " + basicinfo.getarea().strip().upper() + "_PMDATA." + basicinfo.gettableabbr().strip().upper() + " (")
    ddlfile.write("\n")

    # 循环读取有多少字段
    for i in range(len(mapblock[0].gettarcol())):
        if i == 0:
            ddlfile.write(
                mapblock[0].gettarcol()[i].strip() + " " + mapblock[0].gettartype()[i].strip() + " NOT NULL" + "\n")
        elif mapblock[0].gettarcol()[i].strip():
            ddlfile.write(
                "," + mapblock[0].gettarcol()[i].strip() + " " + mapblock[0].gettartype()[
                    i].strip() + " NOT NULL" + "\n")

    ddlfile.write(")")
    ddlfile.write("\n")

    ddlfile.write("WITH (ORIENTATION = COLUMN, COMPRESSION = MIDDLE)")

    if basicinfo.getpdmpk().strip():
        ddlfile.write("\n")
        ddlfile.write("DISTRIBUTE BY HASH (" + basicinfo.getpdmpk().strip().upper() + ")" + ";")
    else:
        ddlfile.write(";")
    ddlfile.write("\n")

    ddlfile.write("\n")

    ddlfile.write(
        "COMMENT ON TABLE " + basicinfo.getarea().strip().upper() + "_PDMDATA." + basicinfo.gettableabbr().strip().upper() + " IS '" + basicinfo.gettablecomment().strip() + "';")
    ddlfile.write("\n")

    ddlfile.write("\n")

    for i in range(len(mapblock[0].gettarcol())):
        if mapblock[0].gettarcol()[i].strip():
            ddlfile.write(
                "COMMENT ON COLUMN " + basicinfo.getarea().strip().upper() + "_PDMDATA." + basicinfo.gettableabbr().strip().upper() + "." +
                mapblock[0].gettarcol()[i].strip() + " IS '" + mapblock[0].gettarcolnm()[i].strip() + "';")
            ddlfile.write("\n")

    ddlfile.write("\n")

    ddlfile.write(
        "CREATE VIEW " + basicinfo.getarea().strip().upper() + "_PDMVIEW." + basicinfo.gettableabbr().strip().upper() + " AS SELECT * FROM " + basicinfo.getarea().strip().upper() + "_PDMDATA." + basicinfo.gettableabbr().strip().upper() + ";")
    ddlfile.write("\n")

    # 生成脚本头
    file.write("/****************************************************************************************************/")
    file.write("\n")

    text = "Script Name: " + script
    for i in range(98 - len(text.encode('gbk'))):
        text += " "
    file.write("/*" + text + "*/")
    file.write("\n")

    text = "Script Description: " + basicinfo.gettablecomment().strip()
    for i in range(98 - len(text.encode('gbk'))):
        text += " "
    file.write("/*" + text + "*/")
    file.write("\n")

    text = "Developer: " + basicinfo.getdeveloper().strip()
    for i in range(98 - len(text.encode('gbk'))):
        text += " "
    file.write("/*" + text + "*/")
    file.write("\n")

    text = "Develop Date: " + basicinfo.getdevelopdt().strip()
    for i in range(98 - len(text.encode('gbk'))):
        text += " "
    file.write("/*" + text + "*/")
    file.write("\n")

    text = "ETL Frequency: " + basicinfo.getetlfreq().strip()
    for i in range(98 - len(text.encode('gbk'))):
        text += " "
    file.write("/*" + text + "*/")
    file.write("\n")

    text = "ETL Policy: " + basicinfo.getetlpolicy().strip()
    for i in range(98 - len(text.encode('gbk'))):
        text += " "
    file.write("/*" + text + "*/")
    file.write("\n")

    text = "Target Table: " + basicinfo.gettableabbr().strip().upper()
    for i in range(98 - len(text.encode('gbk'))):
        text += " "
    file.write("/*" + text + "*/")
    file.write("\n")

    file.write("/*Revision History: Initiated by          Date Revised          Comments                            */")
    file.write("\n")

    file.write("/*                  ")
    text = basicinfo.getdeveloper().strip()
    for i in range(22 - len(text.encode('gbk'))):
        text += " "
    file.write(text)
    text = basicinfo.getdevelopdt().strip()
    for i in range(22 - len(text.encode('gbk'))):
        text += " "
    file.write(text)
    file.write("                                    */")
    file.write("\n")

    file.write("/****************************************************************************************************/")
    file.write("\n")

    file.write("\n")

    file.write("-- COMM--SEG@!;")
    file.write("\n")

    file.write("\n")

    file.write("-- ----------------------procedure实现处理过程开始---------------------------------------------------;")
    file.write("\n")

    file.write("\n")

    file.write("/*创建临时表*/")
    file.write("\n")

    file.write("DROP TABLE " + basicinfo.getetljobname().strip().upper() + "_CUR_I;")
    file.write("\n")

    file.write("\n")

    file.write("-- ERRORNOTEXIT!!;")
    file.write("\n")

    file.write("\n")

    file.write(
        "CREATE TEMPORARY TABLE " + basicinfo.getetljobname().strip().upper() + "_CUR_I (LIKE " + "${" + basicinfo.getarea().strip().upper() + "_" + basicinfo.getsubject().strip().upper() + "DATA}." + basicinfo.gettableabbr().strip().upper() + " INCLUDING ALL EXCLUDING PARTITION);")
    file.write("\n")

    file.write("\n")

    file.write("-- ERRORNOTEXIT!!;")
    file.write("\n")

    file.write("\n")

    # 生成主体代码段
    for f in range(len(mapblock)):
        grp = mapblock[f]

        if grp.getfrontsql().strip():
            file.write(grp.getfrontsql().strip())
            file.write("\n")

        file.write(
            "/***************************************************************************************************/")
        file.write("\n")

        note = "Group" + str(int(grp.getgroupno().strip())) + ": " + grp.getgroupnote().strip()
        for l in range(97 - len(note.encode('gbk'))):
            note += " "
        file.write("/*" + note + "*/")
        file.write("\n")

        file.write(
            "/***************************************************************************************************/")
        file.write("\n")

        file.write("INSERT INTO " + basicinfo.getetljobname().strip().upper() + "_CUR_I")
        file.write("\n")

        file.write("(")
        file.write("\n")

        for i in range(len(grp.gettarcol())):
            fillchar = ""
            if grp.gettarcol()[i].strip():
                if len(grp.gettarcol()[i].strip()) < 60:
                    diff = 60 - len(grp.gettarcol()[i].strip())
                    for j in range(diff):
                        fillchar += " "

                if i == 0:
                    file.write("     " + grp.gettarcol()[i].strip().upper() + fillchar + "/*" + grp.gettarcolnm()[
                        i].strip().upper() + "*/")
                else:
                    file.write("    ," + grp.gettarcol()[i].strip().upper() + fillchar + "/*" + grp.gettarcolnm()[
                        i].strip().upper() + "*/")
                file.write("\n")

        file.write(")")
        file.write("\n")

        file.write("SELECT")
        file.write("\n")

        for i in range(len(grp.getsorenv())):
            # tartext = ""
            if grp.getsormap()[i].strip() == "":
                for j in range(len(grp.getjointab())):
                    if grp.gettarcol()[i].strip().upper() == "SRC_TABLE_NAME":
                        tartext = "'" + grp.getjointab()[0].strip().upper() + "'"
                    elif grp.gettarcol()[i].strip().upper() == "ETL_JOB":
                        tartext = "'${JOB_NAME}'"
                    elif grp.gettarcol()[i].strip().upper() == "SYS_AREA_CTRL_FLD":
                        tartext = "156"  # 时改成156后续优化 tartext = "'" + basicinfo.getarea().strip().upper() + "'"
                    elif grp.gettarcol()[i].strip().upper() == "ETL_INSERT_DT" or grp.gettarcol()[
                        i].strip().upper() == "ETL_UPDATE_DT":
                        tartext = "'${ACC_DATE}'"
                        print(tartext)


def sdmread(folder):
    filelist = []
    targetpath = folder + "\\SDM\\GS\\"

    if os.path.isdir(folder):
        for file in os.listdir(folder):
            filepath = os.path.join(folder, file)
            if os.path.splitext(filepath)[1] in ['.xls', '.xlsx']:
                filelist.append(filepath)
    elif os.path.isfile(folder):
        filelist.append(folder)
        targetpath = os.path.dirname(folder) + "\\SDM\\GS\\"

    if len(filelist) == 0:
        print("目录下没有SDM文件，请确认！")

    if not os.path.exists(targetpath):
        os.makedirs(targetpath)

    for file in filelist:
        # df = ''
        if file.endswith('.xlsx'):
            df = pd.DataFrame(pd.read_excel(file, engine='openpyxl', header=None))
        else:
            df = pd.DataFrame(pd.read_excel(file, header=None))

        # df.to_string('PDM_CHN_AG_AGM_ELIF（协议表）.txt')
        df.fillna('', inplace=True)
        basicinfo, mapblock = sdmanalysis(df)

        scriptproduce(basicinfo, mapblock, targetpath)


if __name__ == '__main__':
    # mysdmpath = sys.argv[1]
    mysdmpath = r'sdm\PDM_CHN_AG_AGM_ELIF（协议表）.xlsx'
    sdmread(mysdmpath)
