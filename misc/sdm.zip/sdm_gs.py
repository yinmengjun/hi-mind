# coding: utf-8
# import sys
# import os
# import xlrd
# from copy import deepcopy
# import pandas as pd

# 海外分行
OVS_AREA = ['MCO', 'TPE', 'TOK', 'SEO', 'KOR', 'HCM', 'SGD', 'DXB', 'SYD', 'PRG', 'FRK', 'LXS', 'LXB', 'ENG', 'LON',
            'TOR', 'NYK', 'JRN']


# SDM基本信息类
class BaseInfo:
    def __init__(self):
        # 模式
        self.subject = ""
        # 地区
        self.area = ""
        # 物理表
        self.tableabbr = ""
        # 物理表注释
        self.tablecomment = ""
        # 开发人员
        self.developer = ""
        # 开发日期
        self.developdt = ""
        # 主键
        self.pdmpk = ""
        # ETL作业名
        self.etljobname = ""
        # ETL跑批频率
        self.etlfreq = ""
        # ETL策略
        self.etlpolicy = ""
        # 数据作业范围条件
        self.datacondition = ""
        # F2策略更新列
        self.f2upsertcols = ""
        # F2策略更新主键
        self.f2upsertkey = ""
        # F5策略主键
        self.f5key = ""
        # F5策略ST_DT
        self.f5stdt = ""
        # F5策略END_DT
        self.f5enddt = ""
        # I策略条件
        self.appendcondition = ""

    def setsubject(self, i):
        self.subject = i

    def setarea(self, i):
        self.area = i

    def settableabbr(self, i):
        self.tableabbr = i

    def settablecomment(self, i):
        self.tablecomment = i

    def setdeveloper(self, i):
        self.developer = i

    def setdevelopdt(self, i):
        self.developdt = i

    def setpdmpk(self, i):
        self.pdmpk = i

    def setetljobname(self, i):
        self.etljobname = i

    def setetlfreq(self, i):
        self.etlfreq = i

    def setetlpolicy(self, i):
        self.etlpolicy = i

    def setdatacondition(self, i):
        self.datacondition = i

    def setf2upsertcols(self, i):
        self.f2upsertcols = i

    def setf2upsertkey(self, i):
        self.f2upsertkey = i

    def setf5key(self, i):
        self.f5key = i

    def setf5stdt(self, i):
        self.f5stdt = i

    def setf5enddt(self, i):
        self.f5enddt = i

    def setappendcondition(self, i):
        self.appendcondition = i

    def getsubject(self):
        return self.subject

    def getarea(self):
        return self.area

    def gettableabbr(self):
        return self.tableabbr

    def gettablecomment(self):
        return self.tablecomment

    def getdeveloper(self):
        return self.developer

    def getdevelopdt(self):
        return self.developdt

    def getpdmpk(self):
        return self.pdmpk

    def getetljobname(self):
        return self.etljobname

    def getetlfreq(self):
        return self.etlfreq

    def getetlpolicy(self):
        return self.etlpolicy

    def getdatacondition(self):
        return self.datacondition

    def getf2upsertcols(self):
        return self.f2upsertcols

    def getf2upsertkey(self):
        return self.f2upsertkey

    def getf5key(self):
        return self.f5key

    def getf5stdt(self):
        return self.f5stdt

    def getf5enddt(self):
        return self.f5enddt

    def getappendcondition(self):
        return self.appendcondition


# SDM逻辑组类
class Group:
    def __init__(self):
        self.groupno = ""
        self.groupnote = ""
        self.ignoreflag = ""
        self.frontsql = ""
        self.behindsql = ""
        self.tarcol = []
        self.tarcolnm = []
        self.tartype = []
        self.sorenv = []
        self.sortab = []
        self.sorcol = []
        self.sorcolnm = []
        self.sormap = []
        self.joinenv = []
        self.jointab = []
        self.jointabalias = []
        self.jointype = []
        self.joincondition = []
        self.condition = []

    def setgroupno(self, i):
        self.groupno = i

    def setgroupnote(self, i):
        self.groupnote = i

    def setignoreflag(self, i):
        self.ignoreflag = i

    def setfrontsql(self, i):
        self.frontsql = i

    def setbehindsql(self, i):
        self.behindsql = i

    def settarcol(self, i):
        self.tarcol.append(i)

    def settarcolnm(self, i):
        self.tarcolnm.append(i)

    def settartype(self, i):
        self.tartype.append(i)

    def setsorenv(self, i):
        self.sorenv.append(i)

    def setsorenv2(self, value):
        self.sorenv = value

    def setsortab(self, i):
        self.sortab.append(i)

    def setsorcol(self, i):
        self.sorcol.append(i)

    def setsorcolnm(self, i):
        self.sorcolnm.append(i)

    def setsormap(self, i):
        self.sormap.append(i)

    def setjoinenv(self, i):
        self.joinenv.append(i)

    def setjoinenv2(self, value):
        self.joinenv = value

    def setjointab(self, i):
        self.jointab.append(i)

    def setjointabalias(self, i):
        self.jointabalias.append(i)

    def setjointype(self, i):
        self.jointype.append(i)

    def setjoincondition(self, i):
        self.joincondition.append(i)

    def setcondition(self, i):
        self.condition.append(i)

    def getgroupno(self):
        return self.groupno

    def getgroupnote(self):
        return self.groupnote

    def getignoreflag(self):
        return self.ignoreflag

    def getfrontsql(self):
        return self.frontsql

    def getbehindsql(self):
        return self.behindsql

    def gettarcol(self):
        return self.tarcol

    def gettarcolnm(self):
        return self.tarcolnm

    def gettartype(self):
        return self.tartype

    def getsorenv(self):
        return self.sorenv

    def getsortab(self):
        return self.sortab

    def getsorcol(self):
        return self.sorcol

    def getsorcolnm(self):
        return self.sorcolnm

    def getsormap(self):
        return self.sormap

    def getjoinenv(self):
        return self.joinenv

    def getjointab(self):
        return self.jointab

    def getjointabalias(self):
        return self.jointabalias

    def getjointype(self):
        return self.jointype

    def getjoincondition(self):
        return self.joincondition

    def getcondition(self):
        return self.condition


def sdmanalysis(sdmsheet):
    pass


def scriptproduce(bas, maps, filepath):
    pass


def sdmread(folder):
    pass


def change_env(src_list, target):
    pass


if __name__ == '__main__':
    # mysdmpath = sys.argv[1]
    mysdmpath = ''
    sdmread(mysdmpath)
