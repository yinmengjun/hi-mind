/****************************************************************************************************/
/*Script Name: pdm_chn_ag_agm_elif0200.sql                                                          */
/*Script Description: 协议表                                                                        */
/*Developer:                                                                                        */
/*Develop Date:                                                                                     */
/*ETL Frequency: Daily                                                                              */
/*ETL Policy: F1:Delete/Insert                                                                      */
/*Target Table: AG_AGM                                                                              */
/*Revision History: Initiated by          Date Revised          Comments                            */
/*                                                                                                  */
/****************************************************************************************************/

-- COMM--SEG@!;

-- ----------------------procedure实现处理过程开始---------------------------------------------------;

/*创建临时表*/
DROP TABLE AG_AGM_ELIF_CUR_I;

-- ERRORNOTEXIT!!;

CREATE TEMPORARY TABLE AG_AGM_ELIF_CUR_I (LIKE ${CHN_PDMDATA}.AG_AGM INCLUDING ALL EXCLUDING PARTITION);

-- ERRORNOTEXIT!!;

select 1
/***************************************************************************************************/
/*Group1: Source Table:[S_ELIF_CUST_APPROVED_LMT_BASE_INFO]                                        */
/***************************************************************************************************/
INSERT INTO AG_AGM_ELIF_CUR_I
(
     UNVS_AGM_NO                                                 /*全域协议号*/
    ,AGM_MODIF                                                   /*协议修饰符*/
    ,AGM_CATG_CD                                                 /*协议类别代码*/
    ,AGM_TP_CD                                                   /*协议类型代码*/
    ,UNVS_CUST_ID                                                /*全域客户号*/
    ,ACCT_OPEN_DT                                                /*开户日期*/
    ,INT_BGN_DT                                                  /*起息日期*/
    ,APPT_EXPY_DT                                                /*约定到期日期*/
    ,AGM_ACTL_EXPY_DT                                            /*协议实际到期日期*/
    ,ACTOPE_INST_ID                                              /*开户机构编号*/
    ,ACTOPE_TLR_ID                                               /*开户柜员编号*/
    ,BLON_INST_ID                                                /*归属机构编号*/
    ,AGM_STS_CD                                                  /*协议状态代码*/
    ,CCY                                                         /*币种*/
    ,ACCTG_SBJEC_CD                                              /*会计科目代码*/
    ,RGN_INOVN_TP_CD                                             /*地区创新类型代码*/
    ,AGM_SRC_SYS_CD                                              /*协议来源系统代码*/
    ,SRC_TABLE_NAME                                              /*源表名称*/
    ,ETL_JOB                                                     /*ETL作业名称*/
    ,SYS_AREA_CTRL_FLD                                           /*系统所在地区*/
    ,ETL_INSERT_DT                                               /*ETL加载日期*/
    ,ETL_UPDATE_DT                                               /*ETL更新日期*/
)
SELECT
select 2
/***************************************************************************************************/
/*Group2: Source Table:[S_ELIF_EFFECT_LMT_BASE_INFO]                                               */
/***************************************************************************************************/
INSERT INTO AG_AGM_ELIF_CUR_I
(
     UNVS_AGM_NO                                                 /*全域协议号*/
    ,AGM_MODIF                                                   /*协议修饰符*/
    ,AGM_CATG_CD                                                 /*协议类别代码*/
    ,AGM_TP_CD                                                   /*协议类型代码*/
    ,UNVS_CUST_ID                                                /*全域客户号*/
    ,ACCT_OPEN_DT                                                /*开户日期*/
    ,INT_BGN_DT                                                  /*起息日期*/
    ,APPT_EXPY_DT                                                /*约定到期日期*/
    ,AGM_ACTL_EXPY_DT                                            /*协议实际到期日期*/
    ,ACTOPE_INST_ID                                              /*开户机构编号*/
    ,ACTOPE_TLR_ID                                               /*开户柜员编号*/
    ,BLON_INST_ID                                                /*归属机构编号*/
    ,AGM_STS_CD                                                  /*协议状态代码*/
    ,CCY                                                         /*币种*/
    ,ACCTG_SBJEC_CD                                              /*会计科目代码*/
    ,RGN_INOVN_TP_CD                                             /*地区创新类型代码*/
    ,AGM_SRC_SYS_CD                                              /*协议来源系统代码*/
    ,SRC_TABLE_NAME                                              /*源表名称*/
    ,ETL_JOB                                                     /*ETL作业名称*/
    ,SYS_AREA_CTRL_FLD                                           /*系统所在地区*/
    ,ETL_INSERT_DT                                               /*ETL加载日期*/
    ,ETL_UPDATE_DT                                               /*ETL更新日期*/
)
SELECT
