#!/bin/bash
#source /etc/profile
source /etl/offline/etc/dbconn/hive2conn_default.cfg
$EXEC_ENGINE -f /etl/offline/sql/tdhload/in/n0006/format/insert_n0006_orc_lawxp_customer.sql

