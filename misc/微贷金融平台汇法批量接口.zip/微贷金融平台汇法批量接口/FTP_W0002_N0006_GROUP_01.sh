#####################################################
#name:          FTP_W0002_N0006_GROUP_01.sh
#purpose:       推送工商和汇法txt数据文件至微贷金融平台；
#step：   
#
#
#revisions:
#ver            date            auther                  description
#------         ---------       ---------               ---------------------
#1.0            2016-10-21      huangpeng               1、create this procedure
#
#####################################################
#!/bin/sh

#加载环境变量
source /etc/profile

#推送工商txt数据文件
sh /etl/offline/app/ftp/etl_ftp.sh 2005

#推送汇法txt数据文件
sh /etl/offline/app/ftp/etl_ftp.sh 2006