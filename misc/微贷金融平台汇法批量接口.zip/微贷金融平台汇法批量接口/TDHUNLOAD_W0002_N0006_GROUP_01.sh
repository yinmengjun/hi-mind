#####################################################
#name:		TDHUNLOAD_W0002_N0006_GROUP_01.sh
#purpose:	工商和汇法数据供给微贷金融平台批量程序
#step：	  
#1.依次调用每一个作业，共21个；
#2.判断批量是否正常
#revisions:
#ver		date				author			description
#------	---------		---------		---------------------
#1.0		2016-09-01	zhujt				1、create this procedure
#
#####################################################

#!/bin/sh
#par_date=20170319
par_date=`date -d last-day +%Y%m%d`

echo "data date:"${par_date}

log_dir=/etl/offline/log/${par_date}/tdhunload/in/n0006/format
log_file=TDHUNLOAD_W0002_N0006_GROUP_01.log
file_name=wdjr_qymc_${par_date}
sh_dir=/etl/offline/app/tdhunload/in/n0006/format
output_dir=/file/out/w0002/output/n0006/${par_date}

[ -d ${log_dir} ] || mkdir -p ${log_dir}

echo "" | tee -a ${log_dir}/${log_file}
echo "==============================[ `date +\"%Y-%m-%d %T\"` ]==============================" | tee -a ${log_dir}/${log_file}
echo "Begin to run group job !" | tee -a ${log_dir}/${log_file}

find /file/in/n0006/input/offline/format/${par_date}/wdjr_qymc_${par_date}.ok >> ${log_dir}/${log_file} 2>&1

if [ $? -eq 0 ]
	then
		echo ""  | tee -a ${log_dir}/${log_file}

#task00《微贷金融企业名称数据入Inceptor》
		sh /etl/offline/app/tdhload/in/n0006/format/TDHLOAD_N0006_ORC_WDJR_QYMC.sh 
	  ret00=$?
	  if [ ${ret00} -eq 0 ]
	  then
		  echo "Run job task00 succeeded !" | tee -a ${log_dir}/${log_file}	
		  echo "" | tee -a ${log_dir}/${log_file}
	   else
		  echo "" | tee -a ${log_dir}/${log_file}
		  echo "Run job task00 failed !" | tee -a ${log_dir}/${log_file}
	   fi
	
#task0《工商数据卸数存储过程跑批》
		sh ${sh_dir}/TDHUNLOAD_W0002_N0006_IC_DATA.sh 
		ret0=$?
		if [ ${ret0} -eq 0 ]
		then
			echo "Run job task0 succeeded !" | tee -a ${log_dir}/${log_file}	
			echo "" | tee -a ${log_dir}/${log_file}
		else
			echo "" | tee -a ${log_dir}/${log_file}
			echo "Run job task0 failed !" | tee -a ${log_dir}/${log_file}
		fi

#task1《企业基本信息表》
		sh ${sh_dir}/TDHUNLOAD_W0002_N0006_HSYH_QYZT.sh 
		ret1=$?
		if [ ${ret1} -eq 0 ]
		then
			echo "Run job task1 succeeded !" | tee -a ${log_dir}/${log_file}	
			echo "" | tee -a ${log_dir}/${log_file}
		else
			echo "" | tee -a ${log_dir}/${log_file}
			echo "Run job task1 failed !" | tee -a ${log_dir}/${log_file}
		fi

#task2《对外投资信息表》
		sh ${sh_dir}/TDHUNLOAD_W0002_N0006_HSYH_DWTZ.sh 
		ret2=$?
		if [ ${ret2} -eq 0 ]
		then
			echo "Run job task2 succeeded !" | tee -a ${log_dir}/${log_file}	
			echo "" | tee -a ${log_dir}/${log_file}
		else
			echo "" | tee -a ${log_dir}/${log_file}
			echo "Run job task2 failed !" | tee -a ${log_dir}/${log_file}
		fi
		
#task3《分支机构信息表》
		sh ${sh_dir}/TDHUNLOAD_W0002_N0006_HSYH_FZJGXX.sh 
		ret3=$?
		if [ ${ret3} -eq 0 ]
		then
			echo "Run job task3 succeeded !" | tee -a ${log_dir}/${log_file}	
			echo "" | tee -a ${log_dir}/${log_file}
		else
			echo "" | tee -a ${log_dir}/${log_file}
			echo "Run job task3 failed !" | tee -a ${log_dir}/${log_file}
		fi
		
#task4《股东出资信息表》
		sh ${sh_dir}/TDHUNLOAD_W0002_N0006_HSYH_GDCZXX.sh 
		ret4=$?
		if [ ${ret4} -eq 0 ]
		then
			echo "Run job task4 succeeded !" | tee -a ${log_dir}/${log_file}	
			echo "" | tee -a ${log_dir}/${log_file}
		else
			echo "" | tee -a ${log_dir}/${log_file}
			echo "Run job task4 failed !" | tee -a ${log_dir}/${log_file}
		fi

#task5《管理人员信息表》
		sh ${sh_dir}/TDHUNLOAD_W0002_N0006_HSYH_GLRYXX.sh 
		ret5=$?
		if [ ${ret5} -eq 0 ]
		then
			echo "Run job task5 succeeded !" | tee -a ${log_dir}/${log_file}	
			echo "" | tee -a ${log_dir}/${log_file}
		else
			echo "" | tee -a ${log_dir}/${log_file}
			echo "Run job task5 failed !" | tee -a ${log_dir}/${log_file}
		fi

#task6《股权出质信息表》
		sh ${sh_dir}/TDHUNLOAD_W0002_N0006_HSYH_GQCZXX.sh 
		ret6=$?
		if [ ${ret6} -eq 0 ]
		then
			echo "Run job task6 succeeded !" | tee -a ${log_dir}/${log_file}	
			echo "" | tee -a ${log_dir}/${log_file}
		else
			echo "" | tee -a ${log_dir}/${log_file}
			echo "Run job task6 failed !" | tee -a ${log_dir}/${log_file}
		fi

#task7《动产抵押信息》
		sh ${sh_dir}/TDHUNLOAD_W0002_N0006_HSYH_DCDYXX.sh 
		ret7=$?
		if [ ${ret7} -eq 0 ]
		then
			echo "Run job task7 succeeded !" | tee -a ${log_dir}/${log_file}	
			echo "" | tee -a ${log_dir}/${log_file}
		else
			echo "" | tee -a ${log_dir}/${log_file}
			echo "Run job task7 failed !" | tee -a ${log_dir}/${log_file}
		fi

#task8《经营异常信息表》
		sh ${sh_dir}/TDHUNLOAD_W0002_N0006_HSYH_JYYCXX.sh 
		ret8=$?
		if [ ${ret8} -eq 0 ]
		then
			echo "Run job task8 succeeded !" | tee -a ${log_dir}/${log_file}	
			echo "" | tee -a ${log_dir}/${log_file}
		else
			echo "" | tee -a ${log_dir}/${log_file}
			echo "Run job task8 failed !" | tee -a ${log_dir}/${log_file}
		fi
		
#task9《其他部门行政处罚信息表》
		sh ${sh_dir}/TDHUNLOAD_W0002_N0006_HSYH_QTXZCF.sh 
		ret9=$?
		if [ ${ret9} -eq 0 ]
		then
			echo "Run job task9 succeeded !" | tee -a ${log_dir}/${log_file}	
			echo "" | tee -a ${log_dir}/${log_file}
		else
			echo "" | tee -a ${log_dir}/${log_file}
			echo "Run job task9 failed !" | tee -a ${log_dir}/${log_file}
		fi

#task10《企业变更信息表》
		sh ${sh_dir}/TDHUNLOAD_W0002_N0006_HSYH_QYBGXX.sh 
		ret10=$?
		if [ ${ret10} -eq 0 ]
		then
			echo "Run job task10 succeeded !" | tee -a ${log_dir}/${log_file}	
			echo "" | tee -a ${log_dir}/${log_file}
		else
			echo "" | tee -a ${log_dir}/${log_file}
			echo "Run job task10 failed !" | tee -a ${log_dir}/${log_file}
		fi

#task11《企业清算信息表》
		sh ${sh_dir}/TDHUNLOAD_W0002_N0006_HSYH_QYQSXX.sh 
		ret11=$?
		if [ ${ret11} -eq 0 ]
		then
			echo "Run job task11 succeeded !" | tee -a ${log_dir}/${log_file}	
			echo "" | tee -a ${log_dir}/${log_file}
		else
			echo "" | tee -a ${log_dir}/${log_file}
			echo "Run job task11 failed !" | tee -a ${log_dir}/${log_file}
		fi

#task12《行政处罚信息表》
		sh ${sh_dir}/TDHUNLOAD_W0002_N0006_HSYH_XZCFXX.sh 
		ret12=$?
		if [ ${ret12} -eq 0 ]
		then
			echo "Run job task12 succeeded !" | tee -a ${log_dir}/${log_file}	
			echo "" | tee -a ${log_dir}/${log_file}
		else
			echo "" | tee -a ${log_dir}/${log_file}
			echo "Run job task12 failed !" | tee -a ${log_dir}/${log_file}
		fi

#task13《严重违法信息表》
		sh ${sh_dir}/TDHUNLOAD_W0002_N0006_HSYH_YZWFXX.sh 
		ret13=$?
		if [ ${ret13} -eq 0 ]
		then
			echo "Run job task13 succeeded !" | tee -a ${log_dir}/${log_file}	
			echo "" | tee -a ${log_dir}/${log_file}
		else
			echo "" | tee -a ${log_dir}/${log_file}
			echo "Run job task13 failed !" | tee -a ${log_dir}/${log_file}
		fi
		
#task14《其他部门行政许可信息》
		sh ${sh_dir}/TDHUNLOAD_W0002_N0006_HSYH_QTXZXK.sh 
		ret14=$?
		if [ ${ret14} -eq 0 ]
		then
			echo "Run job task14 succeeded !" | tee -a ${log_dir}/${log_file}	
			echo "" | tee -a ${log_dir}/${log_file}
		else
			echo "" | tee -a ${log_dir}/${log_file}
			echo "Run job task14 failed !" | tee -a ${log_dir}/${log_file}
		fi

#判断批量是否正常
		ret01=`expr ${ret00} + ${ret0} + ${ret1} + ${ret2} + ${ret3} + ${ret4} + ${ret5} + ${ret6} + ${ret7} + ${ret8} + ${ret9} + ${ret10} + ${ret11} + ${ret12} + ${ret13} + ${ret14}`
		
		if [ ${ret01} -eq 0 ]
		then
			echo "Run ic group job succeeded !" | tee -a ${log_dir}/${log_file}	
			echo "" | tee -a ${log_dir}/${log_file}
			
		else
			echo "" | tee -a ${log_dir}/${log_file}
			echo "Run ic group job some step failed !" | tee -a ${log_dir}/${log_file}
		fi

else
	echo "not find ${file_name}.txt !"  | tee -a ${log_dir}/${log_file}
  mkdir -p ${output_dir}
fi

echo "" | tee -a ${log_dir}/${log_file}
echo "==============================[ `date +\"%Y-%m-%d %T\"` ]==============================" | tee -a ${log_dir}/${log_file}
echo "Begin to run lawxp group job !" | tee -a ${log_dir}/${log_file}

[ -f /file/in/n0006/input/offline/format/${par_date}/lawxp_customer_${par_date}.ok ] && find /file/in/n0006/input/offline/format/${par_date}/lawxp_customer_${par_date}.txt >> ${log_dir}/${log_file} 2>&1

if [ $? -eq 0 ]
then
	echo "" | tee -a ${log_dir}/${log_file}
	
	#task15《执行公开信息表》
	sh ${sh_dir}/TDHUNLOAD_W0011_N0006_LAWXP_ZXGKXX.sh
	ret15=$?
	if [ ${ret15} -eq 0 ]
	then
	    echo "Run job task15 succeeded !" | tee -a ${log_dir}/${log_file}
	    echo "" | tee -a ${log_dir}/${log_file}
	else
	    echo "" | tee -a ${log_dir}/${log_file}
	    echo "Run job task15 failed !" | tee -a ${log_dir}/${log_file}
	fi
	
	#task16《失信老赖名单表》
	sh ${sh_dir}/TDHUNLOAD_W0011_N0006_LAWXP_SXLLMD.sh
	ret16=$?
	if [ ${ret16} -eq 0 ]
	then
	    echo "Run job task16 succeeded !" | tee -a ${log_dir}/${log_file}
	    echo "" | tee -a ${log_dir}/${log_file}
	else
	    echo "" | tee -a ${log_dir}/${log_file}
	    echo "Run job task16 failed !" | tee -a ${log_dir}/${log_file}
	fi
	
	#task17《民商事裁判文书表》
	sh ${sh_dir}/TDHUNLOAD_W0011_N0006_LAWXP_MSSCPWS.sh
	ret17=$?
	if [ ${ret17} -eq 0 ]
	then
	    echo "Run job task17 succeeded !" | tee -a ${log_dir}/${log_file}
	    echo "" | tee -a ${log_dir}/${log_file}
	else
	    echo "" | tee -a ${log_dir}/${log_file}
	    echo "Run job task17 failed !" | tee -a ${log_dir}/${log_file}
	fi
	
	#task18《民商事审判流程表》
	sh ${sh_dir}/TDHUNLOAD_W0011_N0006_LAWXP_MSSSPLC.sh
	ret18=$?
	if [ ${ret18} -eq 0 ]
	then
	    echo "Run job task18 succeeded !" | tee -a ${log_dir}/${log_file}
	    echo "" | tee -a ${log_dir}/${log_file}
	else
	    echo "" | tee -a ${log_dir}/${log_file}
	    echo "Run job task18 failed !" | tee -a ${log_dir}/${log_file}
	fi
	
	#task19《行政违法记录表》
	sh ${sh_dir}/TDHUNLOAD_W0011_N0006_LAWXP_XZWFJL.sh
	ret19=$?
	if [ ${ret19} -eq 0 ]
	then
	    echo "Run job task19 succeeded !" | tee -a ${log_dir}/${log_file}
	    echo "" | tee -a ${log_dir}/${log_file}
	else
	    echo "" | tee -a ${log_dir}/${log_file}
	    echo "Run job task19 failed !" | tee -a ${log_dir}/${log_file}
	fi
	
	#task20《欠税名单表》
	sh ${sh_dir}/TDHUNLOAD_W0011_N0006_LAWXP_QSMD.sh
	ret20=$?
	if [ ${ret20} -eq 0 ]
	then
	    echo "Run job task20 succeeded !" | tee -a ${log_dir}/${log_file}
	    echo "" | tee -a ${log_dir}/${log_file}
	else
	    echo "" | tee -a ${log_dir}/${log_file}
	    echo "Run job task20 failed !" | tee -a ${log_dir}/${log_file}
	fi
	
	#task21《纳税非正常户表》
	sh ${sh_dir}/TDHUNLOAD_W0011_N0006_LAWXP_LSFZCH.sh
	ret21=$?
	if [ ${ret21} -eq 0 ]
	then
	    echo "Run job task21 succeeded !" | tee -a ${log_dir}/${log_file}
	    echo "" | tee -a ${log_dir}/${log_file}
	else
	    echo "" | tee -a ${log_dir}/${log_file}
	    echo "Run job task21 failed !" | tee -a ${log_dir}/${log_file}
	fi
	
	#判断批量是否正常
	ret02=`expr ${ret15} + ${ret16} + ${ret17} + ${ret18} + ${ret19} + ${ret20} + ${ret21}`
	
	if [ ${ret02} -eq 0 ]
	then
	    echo "Run lawxp group job succeeded !" | tee -a ${log_dir}/${log_file}
	    echo "" | tee -a ${log_dir}/${log_file}
	    
	else
	    echo "" | tee -a ${log_dir}/${log_file}
	    echo "Run lawxp group job some step failed !" | tee -a ${log_dir}/${log_file}
	fi
else
	echo "not find /file/in/n0006/input/offline/format/${par_date}/lawxp_customer_${par_date}.ok or /file/in/n0006/input/offline/format/${par_date}/lawxp_customer_${par_date}.txt !"  | tee -a ${log_dir}/${log_file}
  	mkdir -p /file/out/w0011/output/n0006/${par_date}
fi
		
#推送txt数据文件
sh /etl/offline/app/ftp/FTP_W0002_N0006_GROUP_01.sh 
ret03=$?
if [ ${ret03} -eq 0 ]
then
	echo "Run job push data succeeded !" | tee -a ${log_dir}/${log_file}	
	echo "" | tee -a ${log_dir}/${log_file}
else
	echo "" | tee -a ${log_dir}/${log_file}
	echo "Run job push data failed !" | tee -a ${log_dir}/${log_file}
fi
#判断整体跑批是否正常
ret01=${ret01:-0}
ret02=${ret02:-0}
ret=`expr ${ret01} + ${ret02} + ${ret03}`

echo "ExitCode: ${ret}" | tee -a ${log_dir}/${log_file}
echo "Run job log: ${log_dir}/${log_file}" | tee -a ${log_dir}/${log_file}
echo "" | tee -a ${log_dir}/${log_file}
echo "==============================[ `date +\"%Y-%m-%d %T\"` ]==============================" | tee -a ${log_dir}/${log_file}
echo "" | tee -a ${log_dir}/${log_file}

exit ${ret}
