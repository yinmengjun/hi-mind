create_tables_n0006_orc_lawxp_customer.sql /etl/offline/sql/tdhload/in/n0006/format
insert_n0006_orc_lawxp_customer.sql /etl/offline/sql/tdhload/in/n0006/format

n0006_orc_lawxp_customer.kjb /etl/offline/app/kettle/in/n0006/job/format

n0006_orc_lawxp_customer.ktr /etl/offline/app/kettle/in/n0006/transform/format

TDHLOAD_N0006_ORC_LAWXP_CUSTOMER.sh /etl/offline/app/tdhload/in/n0006/format
insert_n0006_orc_lawxp_customer.sh /etl/offline/app/tdhload/in/n0006/format

insert_w0011_n0006_lawxp_zxgkxx.sql /etl/offline/sql/tdhunload/in/n0006/format
insert_w0011_n0006_lawxp_sxllmd.sql /etl/offline/sql/tdhunload/in/n0006/format
insert_w0011_n0006_lawxp_msscpws.sql /etl/offline/sql/tdhunload/in/n0006/format
insert_w0011_n0006_lawxp_msssplc.sql /etl/offline/sql/tdhunload/in/n0006/format
insert_w0011_n0006_lawxp_xzwfjl.sql /etl/offline/sql/tdhunload/in/n0006/format
insert_w0011_n0006_lawxp_qsmd.sql /etl/offline/sql/tdhunload/in/n0006/format
insert_w0011_n0006_lawxp_lsfzch.sql /etl/offline/sql/tdhunload/in/n0006/format

W0011_N0006_LAWXP_ZXGKXX.ktr /etl/offline/app/kettle/in/n0006/transform/format
W0011_N0006_LAWXP_SXLLMD.ktr /etl/offline/app/kettle/in/n0006/transform/format
W0011_N0006_LAWXP_MSSCPWS.ktr /etl/offline/app/kettle/in/n0006/transform/format
W0011_N0006_LAWXP_MSSSPLC.ktr /etl/offline/app/kettle/in/n0006/transform/format
W0011_N0006_LAWXP_XZWFJL.ktr /etl/offline/app/kettle/in/n0006/transform/format
W0011_N0006_LAWXP_QSMD.ktr /etl/offline/app/kettle/in/n0006/transform/format
W0011_N0006_LAWXP_LSFZCH.ktr /etl/offline/app/kettle/in/n0006/transform/format

W0011_N0006_LAWXP_ZXGKXX.kjb /etl/offline/app/kettle/in/n0006/job/format
W0011_N0006_LAWXP_SXLLMD.kjb /etl/offline/app/kettle/in/n0006/job/format
W0011_N0006_LAWXP_MSSCPWS.kjb /etl/offline/app/kettle/in/n0006/job/format
W0011_N0006_LAWXP_MSSSPLC.kjb /etl/offline/app/kettle/in/n0006/job/format
W0011_N0006_LAWXP_XZWFJL.kjb /etl/offline/app/kettle/in/n0006/job/format
W0011_N0006_LAWXP_QSMD.kjb /etl/offline/app/kettle/in/n0006/job/format
W0011_N0006_LAWXP_LSFZCH.kjb /etl/offline/app/kettle/in/n0006/job/format

TDHUNLOAD_W0011_N0006_LAWXP_ZXGKXX.sh /etl/offline/app/tdhunload/in/n0006/format
TDHUNLOAD_W0011_N0006_LAWXP_SXLLMD.sh /etl/offline/app/tdhunload/in/n0006/format
TDHUNLOAD_W0011_N0006_LAWXP_MSSCPWS.sh /etl/offline/app/tdhunload/in/n0006/format
TDHUNLOAD_W0011_N0006_LAWXP_MSSSPLC.sh /etl/offline/app/tdhunload/in/n0006/format
TDHUNLOAD_W0011_N0006_LAWXP_XZWFJL.sh /etl/offline/app/tdhunload/in/n0006/format
TDHUNLOAD_W0011_N0006_LAWXP_QSMD.sh /etl/offline/app/tdhunload/in/n0006/format
TDHUNLOAD_W0011_N0006_LAWXP_LSFZCH.sh /etl/offline/app/tdhunload/in/n0006/format
TDHUNLOAD_W0011_N0006_GROUP_01.sh /etl/offline/app/tdhunload/in/n0006/format
TDHUNLOAD_W0002_N0006_GROUP_01.sh /etl/offline/app/tdhunload/in/n0006/format

FTP_W0002_N0006_GROUP_01.sh /etl/offline/app/ftp