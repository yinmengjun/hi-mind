#####################################################
#name:      TDHLOAD_N0006_ORC_LAWXP_CUSTOMER.sh
#purpose：  汇法网数据请求客户名单列表数据入Inceptor
#step：
#1.判断源文件是否准备好；
#2.删除hdfs目录文件；
#3.执行job。
#revisions:
#ver         date            author           description
#------   --------------   ---------    ---------------------
#1.0         2016-03-09      yinjun
#
#####################################################

#!/bin/sh

curr_date=`date +%Y%m%d`

log_file=TDHLOAD_N0006_ORC_LAWXP_CUSTOMER.log
table_name=n0006_orc_lawxp_customer
file_name=lawxp_customer

log_dir=/etl/offline/log/${curr_date}/tdhload/in/n0006/format
file_dir=/file/in/n0006/input/offline/format/${curr_date}
kjb_site=/etl/offline/app/kettle/in/n0006/job/format/${table_name}.kjb
local_dir=/hstdh/in/n0006/input/offline/format/${table_name}
ftpsh_dir=/etl/offline/app/ftp

kitchen_site=/etl/offline/bin/ketl/data-integration/kitchen.sh
sqoop_link=`cat /etl/offline/etc/sqoop/ssh_sqoop.cfg`

source /etc/profile

[ -d ${log_dir} ] || mkdir -p ${log_dir}

echo "" | tee -a ${log_dir}/${log_file}
echo "==============================[ `date +\"%Y-%m-%d %T\"` ]==============================" | tee -a ${log_dir}/${log_file}
echo "Begin to run job !" | tee -a ${log_dir}/${log_file}

sh ${ftpsh_dir}/etl_ftp.sh 1013 >> ${log_dir}/${log_file} 2>&1

if [ $? -eq 0 ]
then
    #echo "Run ftp job succeeded !"  | tee -a ${log_dir}/${log_file}
    echo "Run ftp job ended !"  | tee -a ${log_dir}/${log_file}
    
    echo "" | tee -a ${log_dir}/${log_file}
    echo "==============================[ `date +\"%Y-%m-%d %T\"` ]==============================" | tee -a ${log_dir}/${log_file}
    #echo "find ${file_name}_${curr_date}.txt !" | tee -a ${log_dir}/${log_file}
    echo "find ${file_name}_${curr_date}.ok and ${file_name}_${curr_date}.txt !" | tee -a ${log_dir}/${log_file}
    echo "" | tee -a ${log_dir}/${log_file}
    
    #find ${file_dir}/${file_name}_${curr_date}.txt >> ${log_dir}/${log_file} 2>&1
    [ -f ${file_dir}/${file_name}_${curr_date}.ok ] && find ${file_dir}/${file_name}_${curr_date}.txt >> ${log_dir}/${log_file} 2>&1
    
    if [ $? -eq 0 ]
    then
        echo "" | tee -a ${log_dir}/${log_file}
        
        count=`cat ${file_dir}/${file_name}_${curr_date}.txt |wc -l`
        
        if [ $count -gt 0 ]
        then
            echo "" | tee -a ${log_dir}/${log_file}
            echo "count ${file_name}_${curr_date}.txt : $count!" | tee -a ${log_dir}/${log_file}
        else
            echo "${file_name}_${curr_date}.txt is empty !" | tee -a ${log_dir}/${log_file}
            echo "ExitCode:0" | tee -a ${log_dir}/${log_file}
            echo "Run job log: ${log_dir}/${log_file}" | tee -a ${log_dir}/${log_file}
            echo "" | tee -a ${log_dir}/${log_file}
            echo "==============================[ `date +\"%Y-%m-%d %T\"` ]==============================" | tee -a ${log_dir}/${log_file}
            echo "" | tee -a ${log_dir}/${log_file}
            exit
        fi
        echo ""  | tee -a ${log_dir}/${log_file}
    else
        #echo "not find ${file_name}_${curr_date}.txt !"  | tee -a ${log_dir}/${log_file}
        echo "not find ${file_name}_${curr_date}.ok or ${file_name}_${curr_date}.txt !"  | tee -a ${log_dir}/${log_file}
        echo "ExitCode:0" | tee -a ${log_dir}/${log_file}
        echo "Run job log: ${log_dir}/${log_file}" | tee -a ${log_dir}/${log_file}
        echo "" | tee -a ${log_dir}/${log_file}
        echo "==============================[ `date +\"%Y-%m-%d %T\"` ]==============================" | tee -a ${log_dir}/${log_file}
        echo "" | tee -a ${log_dir}/${log_file}
        exit
    fi
        
    echo "" | tee -a ${log_dir}/${log_file}
    echo "==============================[ `date +\"%Y-%m-%d %T\"` ]==============================" | tee -a ${log_dir}/${log_file}
    echo "exec ${table_name} job !" | tee -a ${log_dir}/${log_file}
    echo "" | tee -a ${log_dir}/${log_file}
        
    ssh ${sqoop_link} "hdfs dfs -rm -R '${local_dir}'" >> ${log_dir}/${log_file} 2>&1
        
    ${kitchen_site} -file ${kjb_site} >> ${log_dir}/${log_file} 2>&1
        
    ret=$?
        
    if [ ${ret} -eq 0 ]
    then
        echo "" | tee -a ${log_dir}/${log_file}
        echo "exec ${table_name} job succeeded !" | tee -a ${log_dir}/${log_file}
    else
        echo "" | tee -a ${log_dir}/${log_file}
        echo "exec ${table_name} job failed !" | tee -a ${log_dir}/${log_file}
    fi
    
else
    echo "" | tee -a ${log_dir}/${log_file}
    echo "Run ftp job failed !" | tee -a ${log_dir}/${log_file}
fi

echo "ExitCode: ${ret}" | tee -a ${log_dir}/${log_file}
echo "Run job log: ${log_dir}/${log_file}" | tee -a ${log_dir}/${log_file}
echo "" | tee -a ${log_dir}/${log_file}
echo "==============================[ `date +\"%Y-%m-%d %T\"` ]==============================" | tee -a ${log_dir}/${log_file}
echo "" | tee -a ${log_dir}/${log_file}

exit ${ret}