#####################################################
#name:      TDHUNLOAD_W0011_N0006_LAWXP_SXLLMD.sh
#purpose:   汇法网失信老赖名单数据供给微贷金融
#source_table：
#1.WDJR.N0006_ORC_LAWXP_CUSTOMER；
#2.LAWXP.W0011_ORC_LOSE_DBT_LIST_OUT。
#step：
#1.删除TEXT表数据文件；
#2.查询当期失信老赖名单插入TEXT表；
#3.调用kettle作业，生成数据文件；
#4.在txt文件的同目录下生成ok文件。
#revisions:
#ver       date            author            description
#------  ---------      ---------      ---------------------
#1.0       2017-03-14      yinjun
#####################################################

#!/bin/sh

par_date=`date -d last-day +%Y%m%d`

log_dir=/etl/offline/log/${par_date}/tdhunload/in/n0006/format
log_file=TDHUNLOAD_W0011_N0006_LAWXP_SXLLMD.log
text_table=w0011_n0006_lawxp_sxllmd
map_table_sql_dir=/etl/offline/sql/tdhunload/in/n0006/format/insert_w0011_n0006_lawxp_sxllmd.sql
target_dir=/hstdh/out/w0011/output/n0006/offline/format/${text_table}
output_dir=/file/out/w0011/output/n0006

kitchen_site=/etl/offline/bin/ketl/data-integration/kitchen.sh
kjb_site=/etl/offline/app/kettle/in/n0006/job/format/W0011_N0006_LAWXP_SXLLMD.kjb

sqoop_link=`cat /etl/offline/etc/sqoop/ssh_sqoop.cfg`

source /etc/profile

[ -d ${log_dir} ] || mkdir -p ${log_dir}

echo "" | tee -a ${log_dir}/${log_file}
echo "==============================[ `date +\"%Y-%m-%d %T\"` ]==============================" | tee -a ${log_dir}/${log_file}
echo "Prepare to run job !" | tee -a ${log_dir}/${log_file}
echo "data date:"${par_date}
echo "" | tee -a ${log_dir}/${log_file}
echo "Begin to run job !" | tee -a ${log_dir}/${log_file}

#step1
#创建text表指向不存在的路径，hive用户需要有母目录写的权限
ssh ${sqoop_link} 'hdfs dfs -chmod -R 757 /hstdh/out/w0011' >> ${log_dir}/${log_file} 2>&1

ssh ${sqoop_link} 'hdfs dfs -rm '${target_dir}'/*' >> ${log_dir}/${log_file} 2>&1

ret=$?

if [ ${ret} -eq 0 ]
then
    echo "Run job step1 succeeded !" | tee -a ${log_dir}/${log_file}
    echo "" | tee -a ${log_dir}/${log_file}
else
    echo "" | tee -a ${log_dir}/${log_file}
    echo "not files in '${target_dir}' !" | tee -a ${log_dir}/${log_file}
fi
#step2
source /etl/offline/etc/dbconn/hive2conn_default.cfg >> ${log_dir}/${log_file} 2>&1

echo "insert data to text table:" >> ${log_dir}/${log_file} 2>&1

$EXEC_ENGINE -f ${map_table_sql_dir} >> ${log_dir}/${log_file} 2>&1

ret=$?

if [ ${ret} -eq 0 ]
then
    echo "Run job step2 succeeded !" | tee -a ${log_dir}/${log_file}
    echo "" | tee -a ${log_dir}/${log_file}
    
    #step3
    ${kitchen_site} -file ${kjb_site} >> ${log_dir}/${log_file} 2>&1
    
    ret=$?
    
    if [ ${ret} -eq 0 ]
    then
        echo "Run job step3 succeeded !" | tee -a ${log_dir}/${log_file}
        echo "" | tee -a ${log_dir}/${log_file}
        
        #step4
        touch ${output_dir}/${par_date}/LAWXP_SXLLMD_${par_date}.ok >> ${log_dir}/${log_file} 2>&1
        
        ret=$?
        
        if [ ${ret} -eq 0 ]
        then
            echo "Run job step4 succeeded !" | tee -a ${log_dir}/${log_file}
            echo "" | tee -a ${log_dir}/${log_file}
            
        else
            echo "" | tee -a ${log_dir}/${log_file}
            echo "Run job step4 failed ! " | tee -a ${log_dir}/${log_file}
        fi
        
    else
        echo "" | tee -a ${log_dir}/${log_file}
        echo "Run job step3 failed ! " | tee -a ${log_dir}/${log_file}
    fi
    
else
    echo "" | tee -a ${log_dir}/${log_file}
    echo "Run job step2 failed ! " | tee -a ${log_dir}/${log_file}
fi

echo "ExitCode: ${ret}" | tee -a ${log_dir}/${log_file}
echo "Run job log: ${log_dir}/${log_file}" | tee -a ${log_dir}/${log_file}
echo "" | tee -a ${log_dir}/${log_file}
echo "==============================[ `date +\"%Y-%m-%d %T\"` ]==============================" | tee -a ${log_dir}/${log_file}
echo "" | tee -a ${log_dir}/${log_file}

exit ${ret}

