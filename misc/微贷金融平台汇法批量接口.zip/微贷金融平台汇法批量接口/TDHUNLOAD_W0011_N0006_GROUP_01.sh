#####################################################
#name:      TDHUNLOAD_W0011_N0006_GROUP_01.sh
#purpose:   汇法网数据供给微贷金融批量程序
#step：
#1.依次调用每一个作业，共7个；
#2.判断批量是否正常
#revisions:
#ver        date           author            description
#------  ---------       ---------       ---------------------
#1.0        2017-03-14     yinjun
#####################################################

#!/bin/sh

par_date=`date -d last-day +%Y%m%d`

echo "data date:"${par_date}

log_dir=/etl/offline/log/${par_date}/tdhunload/in/n0006/format
log_file=TDHUNLOAD_W0011_N0006_GROUP_01.log
sh_dir=/etl/offline/app/tdhunload/in/n0006/format
ftpsh_dir=/etl/offline/app/ftp

[ -d ${log_dir} ] || mkdir -p ${log_dir}

echo "" | tee -a ${log_dir}/${log_file}
echo "==============================[ `date +\"%Y-%m-%d %T\"` ]==============================" | tee -a ${log_dir}/${log_file}
echo "Begin to run group job !" | tee -a ${log_dir}/${log_file}

#task1《执行公开信息表》
sh ${sh_dir}/TDHUNLOAD_W0011_N0006_LAWXP_ZXGKXX.sh
ret1=$?
if [ ${ret1} -eq 0 ]
then
    echo "Run job task1 succeeded !" | tee -a ${log_dir}/${log_file}
    echo "" | tee -a ${log_dir}/${log_file}
else
    echo "" | tee -a ${log_dir}/${log_file}
    echo "Run job task1 failed !" | tee -a ${log_dir}/${log_file}
fi

#task2《失信老赖名单表》
sh ${sh_dir}/TDHUNLOAD_W0011_N0006_LAWXP_SXLLMD.sh
ret2=$?
if [ ${ret2} -eq 0 ]
then
    echo "Run job task2 succeeded !" | tee -a ${log_dir}/${log_file}
    echo "" | tee -a ${log_dir}/${log_file}
else
    echo "" | tee -a ${log_dir}/${log_file}
    echo "Run job task2 failed !" | tee -a ${log_dir}/${log_file}
fi

#task3《民商事裁判文书表》
sh ${sh_dir}/TDHUNLOAD_W0011_N0006_LAWXP_MSSCPWS.sh
ret3=$?
if [ ${ret3} -eq 0 ]
then
    echo "Run job task3 succeeded !" | tee -a ${log_dir}/${log_file}
    echo "" | tee -a ${log_dir}/${log_file}
else
    echo "" | tee -a ${log_dir}/${log_file}
    echo "Run job task3 failed !" | tee -a ${log_dir}/${log_file}
fi

#task4《民商事审判流程表》
sh ${sh_dir}/TDHUNLOAD_W0011_N0006_LAWXP_MSSSPLC.sh
ret4=$?
if [ ${ret4} -eq 0 ]
then
    echo "Run job task4 succeeded !" | tee -a ${log_dir}/${log_file}
    echo "" | tee -a ${log_dir}/${log_file}
else
    echo "" | tee -a ${log_dir}/${log_file}
    echo "Run job task4 failed !" | tee -a ${log_dir}/${log_file}
fi

#task5《行政违法记录表》
sh ${sh_dir}/TDHUNLOAD_W0011_N0006_LAWXP_XZWFJL.sh
ret5=$?
if [ ${ret5} -eq 0 ]
then
    echo "Run job task5 succeeded !" | tee -a ${log_dir}/${log_file}
    echo "" | tee -a ${log_dir}/${log_file}
else
    echo "" | tee -a ${log_dir}/${log_file}
    echo "Run job task5 failed !" | tee -a ${log_dir}/${log_file}
fi

#task6《欠税名单表》
sh ${sh_dir}/TDHUNLOAD_W0011_N0006_LAWXP_QSMD.sh
ret6=$?
if [ ${ret6} -eq 0 ]
then
    echo "Run job task6 succeeded !" | tee -a ${log_dir}/${log_file}
    echo "" | tee -a ${log_dir}/${log_file}
else
    echo "" | tee -a ${log_dir}/${log_file}
    echo "Run job task6 failed !" | tee -a ${log_dir}/${log_file}
fi

#task7《纳税非正常户表》
sh ${sh_dir}/TDHUNLOAD_W0011_N0006_LAWXP_LSFZCH.sh
ret7=$?
if [ ${ret7} -eq 0 ]
then
    echo "Run job task7 succeeded !" | tee -a ${log_dir}/${log_file}
    echo "" | tee -a ${log_dir}/${log_file}
else
    echo "" | tee -a ${log_dir}/${log_file}
    echo "Run job task7 failed !" | tee -a ${log_dir}/${log_file}
fi

#判断批量是否正常
ret=`expr ${ret1} + ${ret2} + ${ret3} + ${ret4} + ${ret5} + ${ret6} + ${ret7}`

if [ ${ret} -eq 0 ]
then
    echo "Run group job succeeded !" | tee -a ${log_dir}/${log_file}
    echo "" | tee -a ${log_dir}/${log_file}
    
    source /etc/profile
    
    #推送txt数据文件
    sh ${ftpsh_dir}/etl_ftp.sh 2006 >> ${log_dir}/${log_file} 2>&1
    ret=$?
    if [ ${ret} -eq 0 ]
    then
        #echo "Run job push data succeeded !" | tee -a ${log_dir}/${log_file}
        echo "Run job push data ended !" | tee -a ${log_dir}/${log_file}
        echo "" | tee -a ${log_dir}/${log_file}
    else
        echo "" | tee -a ${log_dir}/${log_file}
        echo "Run job push data failed !" | tee -a ${log_dir}/${log_file}
    fi
    
else
    echo "" | tee -a ${log_dir}/${log_file}
    echo "Run group job some step failed !" | tee -a ${log_dir}/${log_file}
fi

echo "ExitCode: ${ret}" | tee -a ${log_dir}/${log_file}
echo "Run job log: ${log_dir}/${log_file}" | tee -a ${log_dir}/${log_file}
echo "" | tee -a ${log_dir}/${log_file}
echo "==============================[ `date +\"%Y-%m-%d %T\"` ]==============================" | tee -a ${log_dir}/${log_file}
echo "" | tee -a ${log_dir}/${log_file}

exit ${ret}


